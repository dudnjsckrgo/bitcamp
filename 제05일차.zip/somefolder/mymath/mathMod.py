import math

def square_root(x):
    return math.sqrt(x)

def jegob(x, y):
    return x**2 + y**2